package com.minimini.mod.entity;

import net.minecraft.entity.Entity;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

/** Conejo de los Backrooms: 60 HP, 8 de daño, chillido al empezar a perseguir. */
public class EntityConejo extends EntityMiniBase {
    public float animPersecucion;
    public float animPersecucionPrev;
    private boolean estabaPersiguiendo;
    private int enfriamientoChillido;

    public EntityConejo(World world) {
        super(world, 0.75F, 2.3F);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(60.0D, 0.26D, 8.0D, 40.0D, 0.5D);
    }

    @Override
    protected void initEntityAI() {
        addStandardGoals(1.55D, 0.7D);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote) {
            this.animPersecucionPrev = this.animPersecucion;
            float objetivo = this.isChasing() ? 1.0F : 0.0F;
            this.animPersecucion += (objetivo - this.animPersecucion) * 0.12F;
        } else {
            if (this.enfriamientoChillido > 0) {
                this.enfriamientoChillido--;
            }
            boolean chasing = this.getAttackTarget() != null;
            if (chasing && !this.estabaPersiguiendo && this.enfriamientoChillido == 0) {
                this.playSound(SoundEvents.ENTITY_RABBIT_DEATH, 1.8F, 0.5F + this.rand.nextFloat() * 0.1F);
                this.enfriamientoChillido = 200;
            }
            this.estabaPersiguiendo = chasing;
        }
    }

    public float getAnimPersecucion(float partialTicks) {
        return this.animPersecucionPrev + partialTicks * (this.animPersecucion - this.animPersecucionPrev);
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        boolean ok = super.attackEntityAsMob(target);
        if (ok) {
            this.playSound(SoundEvents.ENTITY_RABBIT_ATTACK, 1.2F, 0.6F);
        }
        return ok;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_RABBIT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RABBIT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RABBIT_DEATH;
    }

    @Override
    protected float getSoundPitch() {
        return 0.5F + this.rand.nextFloat() * 0.15F;
    }

    @Override
    public int getTalkInterval() {
        return 160;
    }
}
