package com.minimini.mod.entity;

import com.minimini.mod.ModPotions;
import com.minimini.mod.ModSounds;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;

import java.util.List;

/** Reproducción de GritoUltrasonicoGoal: aviso de 20 ticks y luego grito con efectos. */
public class AIGritoUltrasonico extends EntityAIBase {
    private final EntityMiniMini minimini;
    private int enfriamiento;
    private int aviso = -1;

    public AIGritoUltrasonico(EntityMiniMini minimini) {
        this.minimini = minimini;
        this.enfriamiento = siguienteEspera();
        this.setMutexBits(2); // LOOK
    }

    private int siguienteEspera() {
        return 300 + this.minimini.getRNG().nextInt(101);
    }

    @Override
    public boolean shouldExecute() {
        if (this.enfriamiento > 0) {
            this.enfriamiento--;
            return false;
        }
        EntityLivingBase target = this.minimini.getAttackTarget();
        return target != null && target.isEntityAlive() && this.minimini.getDistanceSq(target) <= 400.0D;
    }

    @Override
    public boolean shouldContinueExecuting() {
        EntityLivingBase target = this.minimini.getAttackTarget();
        return this.aviso >= 0 && target != null && target.isEntityAlive();
    }

    @Override
    public void startExecuting() {
        this.aviso = 20;
        this.minimini.swingArm(EnumHand.MAIN_HAND);
        this.minimini.world.playSound(null, this.minimini.posX, this.minimini.posY, this.minimini.posZ,
                ModSounds.GRITO_MINIMINI, SoundCategory.HOSTILE, 3.0F, 1.0F);
    }

    @Override
    public void updateTask() {
        EntityLivingBase target = this.minimini.getAttackTarget();
        if (target != null) {
            this.minimini.getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);
        }
        this.aviso--;
        if (this.aviso == 0) {
            this.gritar();
        }
    }

    @Override
    public void resetTask() {
        this.aviso = -1;
        this.enfriamiento = this.siguienteEspera();
    }

    private void gritar() {
        this.minimini.world.playSound(null, this.minimini.posX, this.minimini.posY, this.minimini.posZ,
                ModSounds.GRITO_MINIMINI, SoundCategory.HOSTILE, 4.0F, 1.0F);
        AxisAlignedBB box = this.minimini.getEntityBoundingBox().grow(20.0D);
        List<EntityPlayer> players = this.minimini.world.getEntitiesWithinAABB(EntityPlayer.class, box,
                p -> p != null && p.isEntityAlive() && !p.isSpectator() && this.minimini.canEntityBeSeen(p));
        for (EntityPlayer p : players) {
            p.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 200, 0));
            p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 160, 1));
            p.addPotionEffect(new PotionEffect(ModPotions.OSCURIDAD, 500, 0));
        }
    }
}
