package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

/** Generado a partir del modelo original (4 piezas, textura 64x64). */
public class ModelSonrisas extends ModelPoseBase {
    private static final float PI = 3.14159F;
    private final ModelRenderer[] P = new ModelRenderer[5];
    private ModelRenderer cabeza, brazoDerecho, brazoIzquierdo;

    public ModelSonrisas() {
        initRoot(64, 64);
        P[0] = root;
        build0();
        cabeza = child(root, "cabeza");
        brazoDerecho = child(root, "brazo_derecho");
        brazoIzquierdo = child(root, "brazo_izquierdo");
        savePose();
    }

    private void build0() {
        P[1] = part(P[0], "brazo_derecho", -3.0F, 23.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[1], 24, 13, -4.5F, -23.200001F, -3.0F, 4, 15, 4, -0.3F);
        P[2] = part(P[0], "brazo_izquierdo", 9.0F, 23.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[2], 0, 28, -5.5F, -23.200001F, -3.0F, 4, 15, 4, -0.3F);
        P[3] = part(P[0], "cuerpo", -3.0F, 23.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[3], 0, 0, -1.0F, -23.0F, -3.0F, 8, 24, 4, 0.0F);
        P[4] = part(P[0], "cabeza", -4.5F, 13.8F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[4], 24, 0, 1.5F, -21.0F, -4.0F, 6, 7, 6, -0.4F);
        box(P[4], 16, 32, 1.5F, -14.6F, -4.0F, 6, 2, 6, -0.1F);
        box(P[4], 40, 13, 5.5F, -14.6F, -4.1F, 2, 8, 1, -0.2F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        float s = MathHelper.sin(ageInTicks * 0.08F);
        float t = (s + 1.0F) * 0.5F;
        cabeza.rotationPointY = 13.8F - t * 0.7F;
        cabeza.rotateAngleX = s * 0.02F;
        brazoDerecho.rotationPointY = 23.0F - t * 0.5F;
        brazoIzquierdo.rotationPointY = 23.0F - t * 0.5F;
    }
}
