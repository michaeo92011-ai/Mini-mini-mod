package com.minimini.mod.entity;

import net.minecraft.entity.ai.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/** Mini Mini.exe: 500 HP, 30 de daño, inmune al empuje; grito ultrasónico; da 5 niveles al jugador que lo mata. */
public class EntityMiniMini extends EntityMiniBase {

    public EntityMiniMini(World world) {
        super(world, 0.9F, 2.9F);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(500.0D, 0.3D, 30.0D, 32.0D, 1.0D);
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(1, new AIGritoUltrasonico(this));
        this.tasks.addTask(1, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackMelee(this, 1.0D, false));
        this.tasks.addTask(3, new EntityAIWanderAvoidWater(this, 0.8D));
        this.tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(5, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
    }

    @Override
    public void onDeath(DamageSource cause) {
        super.onDeath(cause);
        if (!this.world.isRemote && cause.getTrueSource() instanceof EntityPlayerMP) {
            ((EntityPlayerMP) cause.getTrueSource()).addExperienceLevel(5);
        }
    }

    @Override
    protected int getExperiencePoints(EntityPlayer player) {
        return 0;
    }
}
