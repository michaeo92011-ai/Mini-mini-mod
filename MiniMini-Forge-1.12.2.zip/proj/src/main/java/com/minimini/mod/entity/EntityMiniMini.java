package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.BossInfo;
import net.minecraft.world.BossInfoServer;
import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentTranslation;

/** Mini Mini.exe: jefe delgado y alto con barra de vida y grito ultrasónico. */
public class EntityMiniMini extends EntityMiniBase {
    private final BossInfoServer bossInfo = new BossInfoServer(
            new TextComponentTranslation("entity.minimini.minimini.name"),
            BossInfo.Color.BLUE, BossInfo.Overlay.PROGRESS);
    private int screamCooldown = 100;

    public EntityMiniMini(World world) {
        super(world, 0.6F, 2.1F);
        this.experienceValue = 30;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(80.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.30D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(6.0D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(40.0D);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote) {
            return;
        }
        if (screamCooldown > 0) {
            screamCooldown--;
        }
        EntityLivingBase target = this.getAttackTarget();
        if (screamCooldown <= 0 && target != null
                && this.getDistanceSq(target) < 400.0D && this.getEntitySenses().canSee(target)) {
            scream();
            screamCooldown = 260 + this.rand.nextInt(120);
        }
    }

    /** Grito ultrasónico: daña y aturde a los jugadores cercanos. */
    private void scream() {
        this.playSound(ModSounds.GRITO, 3.0F, 1.0F);
        for (EntityPlayer player : this.world.getEntitiesWithinAABB(EntityPlayer.class,
                this.getEntityBoundingBox().grow(12.0D))) {
            if (player.capabilities.disableDamage) {
                continue;
            }
            player.attackEntityFrom(DamageSource.causeMobDamage(this), 2.0F);
            player.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 160));
            player.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 1));
            player.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 40));
        }
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        this.bossInfo.setPercent(this.getHealth() / this.getMaxHealth());
    }

    @Override
    public void addTrackingPlayer(EntityPlayerMP player) {
        super.addTrackingPlayer(player);
        this.bossInfo.addPlayer(player);
    }

    @Override
    public void removeTrackingPlayer(EntityPlayerMP player) {
        super.removeTrackingPlayer(player);
        this.bossInfo.removePlayer(player);
    }
}
