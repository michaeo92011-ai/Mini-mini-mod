package com.minimini.mod.client.render;

import com.minimini.mod.MiniMiniMod;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

/** Renderer genérico: un modelo, una textura y el radio de sombra del original. */
public class RenderMiniMob<T extends EntityLiving> extends RenderLiving<T> {
    private final ResourceLocation texture;

    public RenderMiniMob(RenderManager manager, ModelBase model, float shadow, String textureName) {
        super(manager, model, shadow);
        this.texture = new ResourceLocation(MiniMiniMod.MODID, "textures/entity/" + textureName + ".png");
    }

    @Override
    protected ResourceLocation getEntityTexture(T entity) {
        return texture;
    }
}
