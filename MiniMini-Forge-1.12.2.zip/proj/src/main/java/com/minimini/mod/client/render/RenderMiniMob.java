package com.minimini.mod.client.render;

import com.minimini.mod.MiniMiniMod;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

/** Renderer genérico: un modelo, una textura y una escala. */
public class RenderMiniMob<T extends EntityLiving> extends RenderLiving<T> {
    private final ResourceLocation texture;
    private final float sx, sy, sz;

    public RenderMiniMob(RenderManager manager, ModelBase model, float shadow, String textureName,
                         float sx, float sy, float sz) {
        super(manager, model, shadow);
        this.texture = new ResourceLocation(MiniMiniMod.MODID, "textures/entity/" + textureName + ".png");
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
    }

    @Override
    protected ResourceLocation getEntityTexture(T entity) {
        return texture;
    }

    @Override
    protected void preRenderCallback(T entity, float partialTickTime) {
        GlStateManager.scale(sx, sy, sz);
    }
}
