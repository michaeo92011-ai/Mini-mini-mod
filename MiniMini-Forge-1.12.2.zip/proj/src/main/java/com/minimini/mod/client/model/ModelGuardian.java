package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

/** Generado a partir del modelo original (47 piezas, textura 128x128). */
public class ModelGuardian extends ModelPoseBase {
    private static final float PI = 3.14159F;
    private final ModelRenderer[] P = new ModelRenderer[48];


    public ModelGuardian() {
        initRoot(128, 128);
        P[0] = root;
        build0();
        build1();

        savePose();
    }

    private void build0() {
        P[1] = part(P[0], "cuerpo", -2.0F, 11.0F, -1.0F, 0.0F, 0.0F, 0.0F);
        box(P[1], 0, 0, 1.0F, -9.0F, 0.0F, 9, 21, 5, 0.0F);
        P[2] = part(P[0], "brazo_derecho", 0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        P[3] = part(P[2], "brazo_derecho_inferior_r1", -2.0F, -13.0F, -0.5F, 0.0F, 0.0F, 0.0436F);
        box(P[3], 32, 37, -3.0F, -4.0F, -3.0F, 4, 4, 4, -0.2F);
        P[4] = part(P[2], "brazo_derecho_superior_r1", -3.5F, -13.0F, -1.5F, -0.1745F, 0.0F, 0.0436F);
        box(P[4], 28, 9, -2.0F, -9.0F, -1.0F, 5, 9, 5, -0.6F);
        P[5] = part(P[2], "dedos", 8.8F, -13.4211F, -4.2392F, 0.0F, 0.0F, 0.0873F);
        P[6] = part(P[5], "cube_r1", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[6], 36, 45, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[7] = part(P[5], "cube_r2", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[7], 26, 45, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[8] = part(P[5], "cube_r3", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[8], 16, 42, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[9] = part(P[2], "dedos2", 9.6F, -13.4211F, -4.2392F, 0.0F, 0.0F, 0.0873F);
        P[10] = part(P[9], "cube_r4", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[10], 48, 9, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[11] = part(P[9], "cube_r5", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[11], 16, 47, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[12] = part(P[9], "cube_r6", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[12], 46, 45, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[13] = part(P[2], "dedos3", 10.4F, -13.4211F, -4.2392F, 0.0F, 0.0F, 0.0873F);
        P[14] = part(P[13], "cube_r7", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[14], 0, 50, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[15] = part(P[13], "cube_r8", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[15], 48, 37, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[16] = part(P[13], "cube_r9", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[16], 48, 14, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[17] = part(P[2], "dedos4", 11.2F, -13.4211F, -4.2392F, 0.0F, 0.0F, 0.0873F);
        P[18] = part(P[17], "cube_r10", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[18], 46, 50, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[19] = part(P[17], "cube_r11", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[19], 36, 50, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[20] = part(P[17], "cube_r12", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[20], 26, 50, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[21] = part(P[0], "brazo_izquierdo", 0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        P[22] = part(P[21], "brazo_izquierdo_superio_r1", 8.5F, -13.0F, -1.5F, -0.1745F, 0.0F, -0.0436F);
        box(P[22], 32, 23, -1.0F, -9.0F, -1.0F, 5, 9, 5, -0.6F);
        P[23] = part(P[21], "brazo_izquierdo_inferior_r1", 11.0F, -13.0F, -0.5F, 0.0F, 0.0F, -0.0436F);
        box(P[23], 0, 42, -3.0F, -4.0F, -3.0F, 4, 4, 4, -0.2F);
        P[24] = part(P[21], "dedos5", -4.2F, -13.4211F, -4.2392F, 0.0F, 0.0F, -0.0873F);
        P[25] = part(P[24], "cube_r13", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[25], 52, 24, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[26] = part(P[24], "cube_r14", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[26], 52, 19, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[27] = part(P[24], "cube_r15", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[27], 10, 52, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[28] = part(P[21], "dedos6", -3.4F, -13.4211F, -4.2392F, 0.0F, 0.0F, -0.0873F);
        P[29] = part(P[28], "cube_r16", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[29], 20, 55, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[30] = part(P[28], "cube_r17", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[30], 0, 55, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[31] = part(P[28], "cube_r18", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[31], 52, 29, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[32] = part(P[21], "dedos7", -2.6F, -13.4211F, -4.2392F, 0.0F, 0.0F, -0.0873F);
        P[33] = part(P[32], "cube_r19", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[33], 50, 55, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[34] = part(P[32], "cube_r20", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[34], 40, 55, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[35] = part(P[32], "cube_r21", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[35], 30, 55, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[36] = part(P[21], "dedos8", -1.8F, -13.4211F, -4.2392F, 0.0F, 0.0F, -0.0873F);
        P[37] = part(P[36], "cube_r22", 0.0F, 1.4211F, -0.4608F, 1.6581F, 0.0F, 0.0F);
        box(P[37], 10, 57, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.9F);
        P[38] = part(P[36], "cube_r23", 0.0F, 0.3211F, -0.4608F, 0.9163F, 0.0F, 0.0F);
        box(P[38], 56, 47, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.8F);
        P[39] = part(P[36], "cube_r24", 0.0F, -0.5789F, 0.2392F, 0.5672F, 0.0F, 0.0F);
        box(P[39], 56, 42, -1.0F, -1.0F, -1.0F, 2, 2, 3, -0.7F);
        P[40] = part(P[0], "cabeza", -0.5F, 3.7F, -1.0F, 0.0F, 0.0F, 0.0F);
        box(P[40], 0, 26, 0.0F, -9.1F, -1.5F, 8, 8, 8, -0.5F);
        box(P[40], 28, 0, -1.0F, -2.0F, -1.0F, 10, 2, 7, -0.1F);
    }
    private void build1() {
        P[41] = part(P[40], "picos", 4.0F, -11.4F, 2.5F, 0.0F, 0.0F, 0.0F);
        box(P[41], 58, 9, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[41], 62, 24, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[41], 58, 14, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[42] = part(P[40], "picos2", 8.0F, -10.4F, 2.5F, 0.0F, 0.0F, 0.5236F);
        box(P[42], 58, 34, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[42], 62, 29, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[42], 0, 60, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[43] = part(P[40], "picos3", 0.0F, -10.4F, 2.5F, 0.0F, 0.0F, -0.5236F);
        box(P[43], 20, 60, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[43], 60, 62, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[43], 28, 60, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[44] = part(P[40], "picos4", -2.6F, -6.4F, 2.5F, 0.0F, 0.0F, -1.5708F);
        box(P[44], 36, 60, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[44], 0, 65, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[44], 44, 60, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[45] = part(P[40], "picos5", 10.6F, -6.4F, 2.5F, 0.0F, 0.0F, 1.5708F);
        box(P[45], 52, 60, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[45], 16, 65, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[45], 60, 52, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[46] = part(P[40], "picos6", -2.6F, -2.6F, 2.5F, 0.0F, 0.0F, -1.8326F);
        box(P[46], 60, 57, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[46], 24, 65, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[46], 62, 0, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
        P[47] = part(P[40], "picos7", 10.4F, -2.6F, 2.5F, 3.1416F, 0.0F, -1.309F);
        box(P[47], 8, 62, -1.0F, 0.4F, -1.0F, 2, 3, 2, -0.1F);
        box(P[47], 32, 65, -1.0F, -1.6F, -1.0F, 2, 3, 2, -0.4F);
        box(P[47], 62, 19, -1.0F, -3.3F, -1.0F, 2, 3, 2, -0.7F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        resetPose();
        root.rotationPointY -= 7.0F + MathHelper.sin(ageInTicks * 0.08F) * 1.2F;
    }
}
