package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;

import java.util.List;

/**
 * Guardián del Bosque: no hace daño directo (daño 0, no ataca). Su arma es un aura de 20 bloques:
 * lentitud (más fuerte cuanto más cerca) cada 5 ticks y Wither cada 40 ticks.
 */
public class EntityGuardian extends EntityMiniBase {
    private int contadorVoz;

    public EntityGuardian(World world) {
        super(world, 0.9F, 2.5F);
        this.contadorVoz = 300 + this.rand.nextInt(101);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(45.0D, 0.23D, 0.0D, 40.0D, 0.3D);
    }

    @Override
    protected void initEntityAI() {
        addStandardGoals(1.1D, 0.7D);
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        return false;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote || !this.isEntityAlive()) {
            return;
        }
        if (this.ticksExisted % 5 == 0) {
            aplicarEfectos(this.ticksExisted % 40 == 0);
        }
        if (--this.contadorVoz <= 0) {
            this.playSound(ModSounds.GUARDIAN_VOZ, 1.5F, 1.0F);
            this.contadorVoz = 300 + this.rand.nextInt(101);
        }
    }

    private void aplicarEfectos(boolean wither) {
        AxisAlignedBB box = this.getEntityBoundingBox().grow(20.0D);
        List<EntityPlayer> players = this.world.getEntitiesWithinAABB(EntityPlayer.class, box,
                p -> p != null && !p.isSpectator() && p.isEntityAlive());
        for (EntityPlayer p : players) {
            double dist = Math.sqrt(this.getDistanceSq(p));
            if (dist > 20.0D) {
                continue;
            }
            p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, nivelLentitud(dist), true, true));
            if (wither) {
                p.addPotionEffect(new PotionEffect(MobEffects.WITHER, 50, 0, true, true));
            }
        }
    }

    static int nivelLentitud(double d) {
        if (d <= 2.5D) return 4;
        if (d <= 5.0D) return 3;
        if (d <= 9.0D) return 2;
        if (d <= 14.0D) return 1;
        return 0;
    }
}
