package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAxe;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** Guardián del Bosque: gigante y resistente. Ataca si lo hieren o si ve a alguien con un hacha. */
public class EntityGuardian extends EntityMiniBase {

    public EntityGuardian(World world) {
        super(world, 0.9F, 2.8F);
        this.experienceValue = 40;
    }

    @Override
    protected boolean aggressiveByDefault() {
        return false;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class,
                10, true, false, p -> p != null && p.getHeldItemMainhand().getItem() instanceof ItemAxe));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(80.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(10.0D);
        this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(0.6D);
    }

    /** Puede aparecer de día en el bosque (no exige oscuridad). */
    @Override
    public boolean getCanSpawnHere() {
        return this.world.getDifficulty() != EnumDifficulty.PEACEFUL && this.isNotColliding();
    }

    @Override
    public int getTalkInterval() {
        return 200;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.GUARDIAN_VOZ;
    }
}
