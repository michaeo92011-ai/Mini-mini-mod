package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import com.minimini.mod.entity.EntityMiniBase;

/** Generado a partir del modelo original (6 piezas, textura 64x64). */
public class ModelOjosLinterna extends ModelPoseBase {
    private static final float PI = 3.14159F;
    private final ModelRenderer[] P = new ModelRenderer[7];
    private ModelRenderer cabeza, brazoDerecho, brazoIzquierdo, piernaDerecha, piernaIzquierda;

    public ModelOjosLinterna() {
        initRoot(64, 64);
        P[0] = root;
        build0();
        cabeza = child(root, "cabeza");
        brazoDerecho = child(root, "brazo_derecho");
        brazoIzquierdo = child(root, "brazo_izquierdo");
        piernaDerecha = child(root, "pierna_derecha");
        piernaIzquierda = child(root, "pierna_izquierda");
        savePose();
    }

    private void build0() {
        P[1] = part(P[0], "torso", 0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[1], 0, 0, -3.5F, -23.700001F, -2.0F, 7, 12, 4, 0.0F);
        P[2] = part(P[0], "cabeza", 0.0F, 0.8F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[2], 0, 16, -3.0F, -6.0F, -3.0F, 6, 6, 6, -0.2F);
        P[3] = part(P[0], "brazo_derecho", -5.1F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[3], 0, 28, -2.0F, -2.0F, -2.0F, 4, 12, 4, -0.4F);
        P[4] = part(P[0], "brazo_izquierdo", 5.1F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[4], 16, 32, -2.0F, -2.0F, -2.0F, 4, 12, 4, -0.4F);
        P[5] = part(P[0], "pierna_derecha", -1.8F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[5], 22, 0, -2.0F, -0.2F, -2.0F, 4, 12, 4, -0.4F);
        P[6] = part(P[0], "pierna_izquierda", 1.8F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[6], 24, 16, -2.0F, -0.2F, -2.0F, 4, 12, 4, -0.4F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        resetPose();
        cabeza.rotateAngleY = netHeadYaw * 0.0174533F;
        cabeza.rotateAngleX = headPitch * 0.0174533F;
        float ph = limbSwing * 0.6662F;
        piernaDerecha.rotateAngleX = MathHelper.cos(ph) * 1.4F * limbSwingAmount;
        piernaIzquierda.rotateAngleX = MathHelper.cos(ph + PI) * 1.4F * limbSwingAmount;
        boolean atacando = entityIn instanceof EntityMiniBase && ((EntityMiniBase) entityIn).isChasing();
        float sw = this.swingProgress;
        float s1 = MathHelper.sin(sw * PI);
        float s2 = MathHelper.sin((1.0F - (1.0F - sw) * (1.0F - sw)) * PI);
        float alzar = -PI / (atacando ? 1.5F : 2.25F);
        brazoDerecho.rotateAngleX = alzar + s1 * 1.2F - s2 * 0.4F;
        brazoIzquierdo.rotateAngleX = alzar + s1 * 1.2F - s2 * 0.4F;
        brazoDerecho.rotateAngleY = -(0.1F - s1 * 0.6F);
        brazoIzquierdo.rotateAngleY = 0.1F - s1 * 0.6F;
        float z = MathHelper.cos(ageInTicks * 0.09F) * 0.05F + 0.05F;
        float x = MathHelper.sin(ageInTicks * 0.067F) * 0.05F;
        brazoDerecho.rotateAngleZ += z;
        brazoIzquierdo.rotateAngleZ -= z;
        brazoDerecho.rotateAngleX += x;
        brazoIzquierdo.rotateAngleX -= x;
    }
}
