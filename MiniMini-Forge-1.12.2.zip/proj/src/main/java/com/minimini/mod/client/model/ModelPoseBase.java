package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Base para modelos exportados desde Blockbench: jerarquía de piezas, pose inicial y reset. */
public abstract class ModelPoseBase extends ModelBase {
    protected ModelRenderer root;
    private final List<ModelRenderer> all = new ArrayList<ModelRenderer>();
    private final Map<ModelRenderer, Map<String, ModelRenderer>> kids = new HashMap<ModelRenderer, Map<String, ModelRenderer>>();
    private float[][] pose;

    protected void initRoot(int texW, int texH) {
        this.textureWidth = texW;
        this.textureHeight = texH;
        this.root = new ModelRenderer(this);
        this.root.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.all.add(this.root);
    }

    protected ModelRenderer part(ModelRenderer parent, String name, float px, float py, float pz,
                                 float rx, float ry, float rz) {
        ModelRenderer r = new ModelRenderer(this);
        r.setRotationPoint(px, py, pz);
        r.rotateAngleX = rx;
        r.rotateAngleY = ry;
        r.rotateAngleZ = rz;
        parent.addChild(r);
        this.all.add(r);
        Map<String, ModelRenderer> m = this.kids.get(parent);
        if (m == null) {
            m = new HashMap<String, ModelRenderer>();
            this.kids.put(parent, m);
        }
        m.put(name, r);
        return r;
    }

    protected void box(ModelRenderer r, int u, int v, float x, float y, float z, int w, int h, int d, float dil) {
        r.setTextureOffset(u, v);
        r.addBox(x, y, z, w, h, d, dil);
    }

    protected ModelRenderer child(ModelRenderer parent, String name) {
        Map<String, ModelRenderer> m = this.kids.get(parent);
        ModelRenderer r = m == null ? null : m.get(name);
        if (r == null) {
            throw new IllegalStateException("Pieza no encontrada: " + name);
        }
        return r;
    }

    protected void savePose() {
        this.pose = new float[this.all.size()][6];
        for (int i = 0; i < this.all.size(); i++) {
            ModelRenderer r = this.all.get(i);
            this.pose[i] = new float[]{r.rotationPointX, r.rotationPointY, r.rotationPointZ,
                    r.rotateAngleX, r.rotateAngleY, r.rotateAngleZ};
        }
    }

    protected void resetPose() {
        for (int i = 0; i < this.all.size(); i++) {
            ModelRenderer r = this.all.get(i);
            float[] p = this.pose[i];
            r.rotationPointX = p[0];
            r.rotationPointY = p[1];
            r.rotationPointZ = p[2];
            r.rotateAngleX = p[3];
            r.rotateAngleY = p[4];
            r.rotateAngleZ = p[5];
        }
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        this.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
        this.root.render(scale);
    }
}
