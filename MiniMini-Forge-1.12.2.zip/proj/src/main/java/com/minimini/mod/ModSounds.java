package com.minimini.mod;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = MiniMiniMod.MODID)
public class ModSounds {
    public static final SoundEvent GRITO = create("grito_minimini");
    public static final SoundEvent NINO_VOZ = create("nino_voz");
    public static final SoundEvent GUARDIAN_VOZ = create("guardian_voz");
    public static final SoundEvent SONRISAS_SUSURRO = create("sonrisas_susurro");

    private static SoundEvent create(String name) {
        ResourceLocation rl = new ResourceLocation(MiniMiniMod.MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    @SubscribeEvent
    public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
        event.getRegistry().registerAll(GRITO, NINO_VOZ, GUARDIAN_VOZ, SONRISAS_SUSURRO);
    }
}
