package com.minimini.mod;

import com.minimini.mod.potion.PotionOscuridad;
import net.minecraft.potion.Potion;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = MiniMiniMod.MODID)
public class ModPotions {
    public static final Potion OSCURIDAD = new PotionOscuridad();

    @SubscribeEvent
    public static void registerPotions(RegistryEvent.Register<Potion> event) {
        event.getRegistry().register(OSCURIDAD);
    }
}
