package com.minimini.mod.potion;

import com.minimini.mod.MiniMiniMod;
import net.minecraft.potion.Potion;

/** Equivalente al efecto "Oscuridad" de 1.19+ (el efecto visual lo dibuja ClientHooks). */
public class PotionOscuridad extends Potion {
    public PotionOscuridad() {
        super(true, 0x292721);
        setRegistryName(MiniMiniMod.MODID, "oscuridad");
        setPotionName("effect.minimini.oscuridad");
    }
}
