package com.minimini.mod.client;

import com.minimini.mod.MiniMiniMod;
import com.minimini.mod.ModItems;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = MiniMiniMod.MODID, value = Side.CLIENT)
public class ClientModelRegistry {
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ModItems.MINIMINI_SPAWN_EGG, 0,
                new ModelResourceLocation(ModItems.MINIMINI_SPAWN_EGG.getRegistryName(), "inventory"));
    }
}
