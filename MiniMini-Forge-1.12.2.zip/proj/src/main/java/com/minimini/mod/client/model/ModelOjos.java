package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Cabeza cúbica con dos piernas finas (textura 64x32). */
public class ModelOjos extends ModelBase {
    private final ModelRenderer head, legL, legR;

    public ModelOjos() {
        textureWidth = 64;
        textureHeight = 32;

        head = new ModelRenderer(this, 0, 0);
        head.addBox(-4F, -8F, -4F, 8, 8, 8);
        head.setRotationPoint(0F, 16F, 0F);

        legR = new ModelRenderer(this, 0, 16);
        legR.addBox(-1F, 0F, -1F, 2, 8, 2);
        legR.setRotationPoint(-2F, 16F, 0F);

        legL = new ModelRenderer(this, 0, 16);
        legL.mirror = true;
        legL.addBox(-1F, 0F, -1F, 2, 8, 2);
        legL.setRotationPoint(2F, 16F, 0F);
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
        head.render(scale);
        legR.render(scale);
        legL.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        head.rotateAngleY = netHeadYaw * 0.017453292F;
        head.rotateAngleX = headPitch * 0.017453292F;
        legR.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        legL.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
    }
}
