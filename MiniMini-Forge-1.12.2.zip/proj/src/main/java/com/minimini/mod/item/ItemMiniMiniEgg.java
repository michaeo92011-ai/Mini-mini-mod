package com.minimini.mod.item;

import com.minimini.mod.MiniMiniMod;
import com.minimini.mod.entity.EntityMiniMini;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Huevo generador de Mini Mini.exe (item propio con su textura original). */
public class ItemMiniMiniEgg extends Item {
    public ItemMiniMiniEgg() {
        setRegistryName(MiniMiniMod.MODID, "minimini_spawn_egg");
        setTranslationKey("minimini_spawn_egg");
        setCreativeTab(CreativeTabs.MISC);
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand,
                                      EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (world.isRemote) {
            return EnumActionResult.SUCCESS;
        }
        BlockPos target = pos.offset(facing);
        EntityMiniMini mob = new EntityMiniMini(world);
        mob.setLocationAndAngles(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D,
                world.rand.nextFloat() * 360.0F, 0.0F);
        mob.onInitialSpawn(world.getDifficultyForLocation(target), null);
        world.spawnEntity(mob);
        if (!player.capabilities.isCreativeMode) {
            player.getHeldItem(hand).shrink(1);
        }
        return EnumActionResult.SUCCESS;
    }
}
