package com.minimini.mod.proxy;

import com.minimini.mod.client.model.ModelConejo;
import com.minimini.mod.client.model.ModelOjos;
import com.minimini.mod.client.render.RenderMiniMob;
import com.minimini.mod.entity.*;
import net.minecraft.client.model.ModelBiped;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityMiniMini.class,
                m -> new RenderMiniMob<EntityMiniMini>(m, new ModelBiped(), 0.5F, "minimini", 0.85F, 1.15F, 0.85F));
        RenderingRegistry.registerEntityRenderingHandler(EntityConejo.class,
                m -> new RenderMiniMob<EntityConejo>(m, new ModelConejo(), 0.4F, "conejo", 1.0F, 1.0F, 1.0F));
        RenderingRegistry.registerEntityRenderingHandler(EntityNino.class,
                m -> new RenderMiniMob<EntityNino>(m, new ModelBiped(), 0.3F, "nino", 0.7F, 0.7F, 0.7F));
        RenderingRegistry.registerEntityRenderingHandler(EntityGuardian.class,
                m -> new RenderMiniMob<EntityGuardian>(m, new ModelBiped(), 0.9F, "guardian_bosque", 1.5F, 1.5F, 1.5F));
        RenderingRegistry.registerEntityRenderingHandler(EntitySonrisas.class,
                m -> new RenderMiniMob<EntitySonrisas>(m, new ModelBiped(), 0.5F, "monstruo_sonrisas", 1.1F, 1.1F, 1.1F));
        RenderingRegistry.registerEntityRenderingHandler(EntityOjosLinterna.class,
                m -> new RenderMiniMob<EntityOjosLinterna>(m, new ModelOjos(), 0.4F, "ojos_linterna", 1.0F, 1.0F, 1.0F));
    }
}
