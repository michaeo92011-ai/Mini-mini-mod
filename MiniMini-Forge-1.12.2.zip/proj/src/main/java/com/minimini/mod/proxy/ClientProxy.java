package com.minimini.mod.proxy;

import com.minimini.mod.client.ClientHooks;
import com.minimini.mod.client.model.*;
import com.minimini.mod.client.render.RenderMiniMob;
import com.minimini.mod.entity.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        MinecraftForge.EVENT_BUS.register(new ClientHooks());

        RenderingRegistry.registerEntityRenderingHandler(EntityMiniMini.class,
                m -> new RenderMiniMob<EntityMiniMini>(m, new ModelMiniMini(), 0.85F, "minimini"));
        RenderingRegistry.registerEntityRenderingHandler(EntityConejo.class,
                m -> new RenderMiniMob<EntityConejo>(m, new ModelConejo(), 0.5F, "conejo"));
        RenderingRegistry.registerEntityRenderingHandler(EntityNino.class,
                m -> new RenderMiniMob<EntityNino>(m, new ModelNino(), 0.4F, "nino"));
        RenderingRegistry.registerEntityRenderingHandler(EntityGuardian.class,
                m -> new RenderMiniMob<EntityGuardian>(m, new ModelGuardian(), 0.5F, "guardian_bosque"));
        RenderingRegistry.registerEntityRenderingHandler(EntitySonrisas.class,
                m -> new RenderMiniMob<EntitySonrisas>(m, new ModelSonrisas(), 0.5F, "monstruo_sonrisas"));
        RenderingRegistry.registerEntityRenderingHandler(EntityOjosLinterna.class,
                m -> new RenderMiniMob<EntityOjosLinterna>(m, new ModelOjosLinterna(), 0.5F, "ojos_linterna"));
    }
}
