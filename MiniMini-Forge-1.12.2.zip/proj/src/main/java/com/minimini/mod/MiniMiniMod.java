package com.minimini.mod;

import com.minimini.mod.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = MiniMiniMod.MODID, name = MiniMiniMod.NAME, version = "2.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class MiniMiniMod {
    public static final String MODID = "minimini";
    public static final String NAME = "Mini Mini.exe";

    @Mod.Instance(MODID)
    public static MiniMiniMod instance;

    @SidedProxy(clientSide = "com.minimini.mod.proxy.ClientProxy", serverSide = "com.minimini.mod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModEntities.register();
        proxy.preInit();
    }
}
