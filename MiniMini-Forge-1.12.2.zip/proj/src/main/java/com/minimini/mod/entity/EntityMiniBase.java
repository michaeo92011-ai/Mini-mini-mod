package com.minimini.mod.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.world.World;

/** Base común (equivale a HostileEntity del original) con el flag "persiguiendo" sincronizado al cliente. */
public abstract class EntityMiniBase extends EntityMob {
    private static final DataParameter<Boolean> CHASING =
            EntityDataManager.createKey(EntityMiniBase.class, DataSerializers.BOOLEAN);

    protected EntityMiniBase(World world, float width, float height) {
        super(world);
        this.setSize(width, height);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(CHASING, Boolean.FALSE);
    }

    public boolean isChasing() {
        return this.dataManager.get(CHASING);
    }

    protected void setAttributes(double health, double speed, double damage, double followRange, double knockbackResist) {
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(health);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(speed);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(damage);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(followRange);
        this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(knockbackResist);
    }

    /** IA estándar del original: nadar, melee, pasear, mirar, y objetivos (venganza + jugador más cercano). */
    protected void addStandardGoals(double meleeSpeed, double wanderSpeed) {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackMelee(this, meleeSpeed, false));
        this.tasks.addTask(5, new EntityAIWanderAvoidWater(this, wanderSpeed));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 12.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.world.isRemote) {
            boolean chasing = this.getAttackTarget() != null;
            if (chasing != this.dataManager.get(CHASING)) {
                this.dataManager.set(CHASING, chasing);
            }
        }
    }
}
