package com.minimini.mod.entity;

import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

/** Base común: IA de combate cuerpo a cuerpo. Si aggressiveByDefault() es false, solo ataca si lo hieren. */
public abstract class EntityMiniBase extends EntityMob {

    protected EntityMiniBase(World world, float width, float height) {
        super(world);
        this.setSize(width, height);
    }

    /** OJO: se llama desde el constructor de la superclase; debe devolver una constante. */
    protected boolean aggressiveByDefault() {
        return true;
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackMelee(this, 1.0D, false));
        this.tasks.addTask(5, new EntityAIWanderAvoidWater(this, 0.8D));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 12.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        if (aggressiveByDefault()) {
            this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
        }
    }
}
