package com.minimini.mod;

import com.minimini.mod.item.ItemMiniMiniEgg;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = MiniMiniMod.MODID)
public class ModItems {
    public static final Item MINIMINI_SPAWN_EGG = new ItemMiniMiniEgg();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(MINIMINI_SPAWN_EGG);
    }
}
