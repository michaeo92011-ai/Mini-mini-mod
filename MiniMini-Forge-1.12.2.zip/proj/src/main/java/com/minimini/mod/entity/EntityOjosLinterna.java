package com.minimini.mod.entity;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;

/** Ojos Linterna: lento (0.1), 30 HP, 12 de daño, con 30 ticks de espera entre golpes. */
public class EntityOjosLinterna extends EntityMiniBase {
    private int enfriamientoGolpe;

    public EntityOjosLinterna(World world) {
        super(world, 0.7F, 1.85F);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(30.0D, 0.1D, 12.0D, 40.0D, 0.2D);
    }

    @Override
    protected void initEntityAI() {
        addStandardGoals(1.0D, 0.8D);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.enfriamientoGolpe > 0) {
            this.enfriamientoGolpe--;
        }
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        if (this.enfriamientoGolpe > 0) {
            return false;
        }
        boolean ok = super.attackEntityAsMob(target);
        if (ok) {
            this.enfriamientoGolpe = 30;
        }
        return ok;
    }
}
