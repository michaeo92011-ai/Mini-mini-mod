package com.minimini.mod.proxy;

public class CommonProxy {
    public void preInit() {
    }
}
