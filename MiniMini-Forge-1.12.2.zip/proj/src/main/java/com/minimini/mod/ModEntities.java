package com.minimini.mod;

import com.minimini.mod.entity.*;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

/**
 * Igual que el mod original: los mobs NO aparecen de forma natural, solo con huevos generadores
 * (Mini Mini tiene su huevo propio; los demás usan huevo vanilla con los colores del original).
 */
public class ModEntities {
    private static int nextId = 0;

    public static void register() {
        reg(EntityMiniMini.class, "minimini", 0, 0);   // su huevo es un item propio (ModItems)
        reg(EntityConejo.class, "conejo", 0xD6D0C2, 0x2B2421);
        reg(EntityNino.class, "nino", 0x111111, 0xEEEEEE);
        reg(EntityGuardian.class, "guardian_bosque", 0xF2F2EC, 0xFFE970);
        reg(EntitySonrisas.class, "monstruo_sonrisas", 0x111111, 0xF8D68E);
        reg(EntityOjosLinterna.class, "ojos_linterna", 0x111111, 0xE8D234);
    }

    private static void reg(Class<? extends Entity> clazz, String name, int eggPrimary, int eggSecondary) {
        ResourceLocation rl = new ResourceLocation(MiniMiniMod.MODID, name);
        String entityName = MiniMiniMod.MODID + "." + name;
        if (eggPrimary == 0 && eggSecondary == 0) {
            EntityRegistry.registerModEntity(rl, clazz, entityName, nextId++, MiniMiniMod.instance, 80, 3, true);
        } else {
            EntityRegistry.registerModEntity(rl, clazz, entityName, nextId++, MiniMiniMod.instance, 80, 3, true,
                    eggPrimary, eggSecondary);
        }
    }
}
