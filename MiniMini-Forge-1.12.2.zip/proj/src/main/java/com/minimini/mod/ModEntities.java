package com.minimini.mod;

import com.minimini.mod.entity.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.fml.common.registry.EntityRegistry;

import java.util.ArrayList;
import java.util.List;

public class ModEntities {
    private static int nextId = 0;

    public static void register() {
        reg(EntityMiniMini.class, "minimini", 0x1B2A8C, 0xD8D8E0);
        reg(EntityConejo.class, "conejo", 0xBEBEBE, 0xB00020);
        reg(EntityNino.class, "nino", 0xE0C040, 0x20208A);
        reg(EntityGuardian.class, "guardian_bosque", 0x3B5A2A, 0xF0D020);
        reg(EntitySonrisas.class, "monstruo_sonrisas", 0x101010, 0xFFFFFF);
        reg(EntityOjosLinterna.class, "ojos_linterna", 0x050505, 0xFFE040);

        Biome[] overworld = overworldBiomes();
        EntityRegistry.addSpawn(EntityMiniMini.class, 1, 1, 1, EnumCreatureType.MONSTER, overworld);
        EntityRegistry.addSpawn(EntityConejo.class, 8, 1, 2, EnumCreatureType.MONSTER, overworld);
        EntityRegistry.addSpawn(EntityNino.class, 6, 1, 1, EnumCreatureType.MONSTER, overworld);
        EntityRegistry.addSpawn(EntitySonrisas.class, 4, 1, 1, EnumCreatureType.MONSTER, overworld);
        EntityRegistry.addSpawn(EntityOjosLinterna.class, 8, 1, 3, EnumCreatureType.MONSTER, overworld);

        Biome[] forests = BiomeDictionary.getBiomes(BiomeDictionary.Type.FOREST).toArray(new Biome[0]);
        EntityRegistry.addSpawn(EntityGuardian.class, 6, 1, 1, EnumCreatureType.CREATURE, forests);
    }

    private static void reg(Class<? extends Entity> clazz, String name, int eggPrimary, int eggSecondary) {
        EntityRegistry.registerModEntity(new ResourceLocation(MiniMiniMod.MODID, name), clazz,
                MiniMiniMod.MODID + "." + name, nextId++, MiniMiniMod.instance, 64, 1, true, eggPrimary, eggSecondary);
    }

    private static Biome[] overworldBiomes() {
        List<Biome> list = new ArrayList<>();
        for (Biome b : Biome.REGISTRY) {
            if (BiomeDictionary.hasType(b, BiomeDictionary.Type.NETHER)
                    || BiomeDictionary.hasType(b, BiomeDictionary.Type.END)
                    || BiomeDictionary.hasType(b, BiomeDictionary.Type.VOID)) {
                continue;
            }
            list.add(b);
        }
        return list.toArray(new Biome[0]);
    }
}
