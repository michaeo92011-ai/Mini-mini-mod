package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import com.minimini.mod.entity.EntityNino;

/** Generado a partir del modelo original (9 piezas, textura 64x64). */
public class ModelNino extends ModelPoseBase {
    private static final float PI = 3.14159F;
    private final ModelRenderer[] P = new ModelRenderer[10];
    private ModelRenderer nino, cuerpo, cabeza, brazoIzquierdo, brazoDerecho, piernaIzquierda, piernaDerecha;

    public ModelNino() {
        initRoot(64, 64);
        P[0] = root;
        build0();
        nino = child(root, "nino");
        piernaIzquierda = child(nino, "pierna_izquierda");
        piernaDerecha = child(nino, "pierna_derecha");
        cuerpo = child(nino, "cuerpo");
        brazoIzquierdo = child(cuerpo, "brazo_izquierdo");
        brazoDerecho = child(cuerpo, "brazo_derecho");
        cabeza = child(cuerpo, "cabeza");
        savePose();
    }

    private void build0() {
        P[1] = part(P[0], "nino", 1.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        P[2] = part(P[1], "pierna_izquierda", 0.5F, -7.5F, -1.0F, 0.0F, 0.0F, 0.0F);
        box(P[2], 0, 28, -1.5F, -0.5F, -1.5F, 3, 8, 3, -0.1F);
        P[3] = part(P[1], "pierna_derecha", -2.5F, -7.5F, -1.0F, 0.0F, 0.0F, 0.0F);
        box(P[3], 20, 26, -1.5F, -0.5F, -1.5F, 3, 8, 3, -0.1F);
        P[4] = part(P[1], "cuerpo", -1.0F, -8.0F, -1.0F, 0.0F, 0.0F, 0.0F);
        P[5] = part(P[4], "torso", 1.0F, 8.0F, 1.0F, 0.0F, 0.0F, 0.0F);
        box(P[5], 0, 0, -4.0F, -17.0F, -3.0F, 6, 9, 4, 0.1F);
        P[6] = part(P[4], "brazo_izquierdo", 4.1288F, -8.5137F, 0.0F, 0.0F, 0.0F, -0.0436F);
        box(P[6], 20, 0, -1.5F, -0.5F, -1.5F, 3, 10, 3, -0.2F);
        P[7] = part(P[4], "brazo_derecho", -5.1288F, -8.5137F, 0.0F, 0.0F, 0.0F, 0.0436F);
        box(P[7], 20, 13, -0.5F, -0.5F, -1.5F, 3, 10, 3, -0.2F);
        P[8] = part(P[4], "cabeza", 0.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[8], 0, 13, -2.5F, -5.0F, -2.5F, 5, 5, 5, 0.0F);
        P[9] = part(P[8], "gorro", 1.0F, 17.0F, 1.0F, 0.0F, 0.0F, 0.0F);
        box(P[9], 32, 0, 1.9F, -22.200001F, -3.5F, 0, 6, 5, 0.0F);
        box(P[9], 32, 10, -3.9F, -22.200001F, -3.5F, 0, 6, 5, 0.0F);
        box(P[9], -1, 23, -4.0F, -22.200001F, -3.5F, 6, 0, 5, 0.0F);
        box(P[9], 31, 20, -4.0F, -22.200001F, 1.5F, 6, 6, 0, 0.0F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        resetPose();
        float t = ageInTicks;
        float cu = ((EntityNino) entityIn).getAnimCuadrupedo(ageInTicks - (float) entityIn.ticksExisted);
        float amt = MathHelper.clamp(limbSwingAmount, 0.0F, 1.0F);
        float ph = limbSwing * 0.6662F;
        float l1 = MathHelper.cos(ph) * 1.1F * amt;
        float l2 = MathHelper.cos(ph + PI) * 1.1F * amt;
        float l3 = MathHelper.cos(ph + PI) * 0.9F * amt;
        float l4 = MathHelper.cos(ph + PI + 0.35F) * 0.9F * amt;
        piernaIzquierda.rotateAngleX += (1.0F - cu) * l1 + cu * l3;
        piernaDerecha.rotateAngleX += (1.0F - cu) * l2 + cu * l4;
        nino.rotationPointY -= MathHelper.abs(MathHelper.sin(ph)) * (0.8F + 0.8F * cu) * amt;
        float v15 = MathHelper.sin(ph * 2.0F) * 0.08F * amt * cu;
        cuerpo.rotateAngleX += MathHelper.sin(t * 0.07F) * 0.03F * (1.0F - cu) + cu * 1.3F + v15;
        cuerpo.rotateAngleY += -MathHelper.cos(ph) * 0.15F * amt * (1.0F - cu);
        cuerpo.rotateAngleZ += MathHelper.cos(ph) * 0.05F * amt * (1.0F - cu);
        float sway = MathHelper.cos(t * 0.09F) * 0.04F + 0.03F;
        float a1 = MathHelper.cos(ph + PI) * 0.9F * amt;
        float a2 = MathHelper.cos(ph) * 0.9F * amt;
        float a3 = -1.3F + MathHelper.cos(ph) * 0.9F * amt;
        float a4 = -1.3F + MathHelper.cos(ph + 0.35F) * 0.9F * amt;
        brazoDerecho.rotateAngleX += (1.0F - cu) * a1 + cu * a3;
        brazoDerecho.rotateAngleZ += sway * (1.0F - cu);
        brazoIzquierdo.rotateAngleX += (1.0F - cu) * a2 + cu * a4;
        brazoIzquierdo.rotateAngleZ += -sway * (1.0F - cu);
        float v22 = 0.0F;
        float sw = this.swingProgress;
        if (sw > 0.0F) {
            float s1 = MathHelper.sin(sw * PI);
            float s2 = MathHelper.sin(MathHelper.clamp(sw * 1.35F - 0.35F, 0.0F, 1.0F) * PI);
            cuerpo.rotateAngleX += -s1 * 0.9F * cu + s1 * 0.15F * (1.0F - cu);
            brazoDerecho.rotateAngleX += -s1 * 1.3F;
            brazoDerecho.rotateAngleZ += s1 * 0.3F;
            brazoIzquierdo.rotateAngleX += -s2 * 1.3F;
            brazoIzquierdo.rotateAngleZ += -s2 * 0.3F;
            v22 = s1 * 0.9F * cu;
        }
        float twitch = 0.0F;
        int paso = (int) (t / 10.0F);
        int h = ((paso * 73856093) ^ (entityIn.getEntityId() * 19349663)) & 65535;
        if (h % 4 == 0) {
            float k = (t % 10.0F) / 10.0F;
            twitch = ((h & 1) == 0 ? 0.45F : -0.45F) * Math.min(1.0F, k * 6.0F) * (1.0F - k);
        }
        cabeza.rotateAngleY += netHeadYaw * 0.0174533F * (1.0F - 0.5F * cu);
        cabeza.rotateAngleX += headPitch * 0.0174533F - cu * 1.3F - v15 + v22;
        cabeza.rotateAngleZ += MathHelper.sin(t * 0.05F) * 0.07F + twitch + MathHelper.sin(t * 1.7F) * 0.06F * cu;
    }
}
