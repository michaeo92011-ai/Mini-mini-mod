package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Conejo alto y delgado de 4 patas (textura 64x32). */
public class ModelConejo extends ModelBase {
    private final ModelRenderer body, head, earL, earR, tail, legFL, legFR, legBL, legBR;

    public ModelConejo() {
        textureWidth = 64;
        textureHeight = 32;

        body = new ModelRenderer(this, 0, 0);
        body.addBox(-3F, -3F, -5F, 6, 6, 10);
        body.setRotationPoint(0F, 17F, 0F);

        head = new ModelRenderer(this, 32, 0);
        head.addBox(-2.5F, -2.5F, -4F, 5, 5, 4);
        head.setRotationPoint(0F, 14F, -5F);

        earR = new ModelRenderer(this, 50, 0);
        earR.addBox(-1F, -6F, -0.5F, 2, 6, 1);
        earR.setRotationPoint(-1.5F, 12F, -3F);

        earL = new ModelRenderer(this, 56, 0);
        earL.addBox(-1F, -6F, -0.5F, 2, 6, 1);
        earL.setRotationPoint(1.5F, 12F, -3F);

        tail = new ModelRenderer(this, 32, 16);
        tail.addBox(-1.5F, -1.5F, 0F, 3, 3, 2);
        tail.setRotationPoint(0F, 15F, 5F);

        legFR = leg(0);
        legFR.setRotationPoint(-2.5F, 19F, -3F);
        legFL = leg(8);
        legFL.setRotationPoint(2.5F, 19F, -3F);
        legBR = leg(16);
        legBR.setRotationPoint(-2.5F, 19F, 3F);
        legBL = leg(24);
        legBL.setRotationPoint(2.5F, 19F, 3F);
    }

    private ModelRenderer leg(int u) {
        ModelRenderer r = new ModelRenderer(this, u, 16);
        r.addBox(-1F, 0F, -1F, 2, 5, 2);
        return r;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
        body.render(scale);
        head.render(scale);
        earR.render(scale);
        earL.render(scale);
        tail.render(scale);
        legFR.render(scale);
        legFL.render(scale);
        legBR.render(scale);
        legBL.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        head.rotateAngleY = netHeadYaw * 0.017453292F;
        head.rotateAngleX = headPitch * 0.017453292F;
        earR.rotateAngleY = head.rotateAngleY;
        earL.rotateAngleY = head.rotateAngleY;
        earR.rotateAngleX = head.rotateAngleX;
        earL.rotateAngleX = head.rotateAngleX;

        float swing = MathHelper.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        legFR.rotateAngleX = swing;
        legBL.rotateAngleX = swing;
        legFL.rotateAngleX = -swing;
        legBR.rotateAngleX = -swing;
    }
}
