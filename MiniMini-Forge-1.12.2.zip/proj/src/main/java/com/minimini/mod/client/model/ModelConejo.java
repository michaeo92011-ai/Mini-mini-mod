package com.minimini.mod.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import com.minimini.mod.entity.EntityConejo;

/** Generado a partir del modelo original (45 piezas, textura 128x128). */
public class ModelConejo extends ModelPoseBase {
    private static final float PI = 3.14159F;
    private final ModelRenderer[] P = new ModelRenderer[46];
    private ModelRenderer conejo, piernaDerecha, piernaIzquierda, cuerpo, brazoDerecho, brazoIzquierdo, cabeza, orejas;
    private ModelRenderer[] garras;

    public ModelConejo() {
        initRoot(128, 128);
        P[0] = root;
        build0();
        build1();
        conejo = child(root, "conejo");
        piernaDerecha = child(conejo, "pierna_derecha");
        piernaIzquierda = child(conejo, "pierna_izquierda");
        cuerpo = child(conejo, "cuerpo");
        brazoDerecho = child(cuerpo, "brazo_derecho");
        brazoIzquierdo = child(cuerpo, "brazo_izquierdo");
        cabeza = child(cuerpo, "cabeza");
        orejas = child(cabeza, "orejas");
        garras = new ModelRenderer[]{
                child(brazoDerecho, "garra_d1"), child(brazoDerecho, "garra_d2"),
                child(brazoDerecho, "garra_d3"), child(brazoDerecho, "garra_d4"),
                child(brazoIzquierdo, "garra_i1"), child(brazoIzquierdo, "garra_i2"),
                child(brazoIzquierdo, "garra_i3"), child(brazoIzquierdo, "garra_i4")};
        savePose();
    }

    private void build0() {
        P[1] = part(P[0], "conejo", -2.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        P[2] = part(P[1], "pierna_derecha", 0.0F, -12.0F, 0.5F, 0.0F, 0.0F, 0.0F);
        box(P[2], 0, 49, -2.0F, -1.0F, -2.0F, 4, 13, 4, -0.1F);
        box(P[2], 20, 66, -1.5F, 10.0F, -3.5F, 3, 2, 3, 0.0F);
        P[3] = part(P[2], "garras_pie_derecho", -1.0F, 12.0F, -1.5F, 0.0F, 0.0F, 0.0F);
        P[4] = part(P[3], "cube_r1", 2.0F, 0.0F, -3.0F, 0.6109F, 0.0F, 0.0F);
        box(P[4], 68, 39, -0.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        box(P[4], 68, 36, -1.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        box(P[4], 68, 33, -2.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        P[5] = part(P[3], "cube_r2", 2.0F, 0.0F, -2.0F, -0.1309F, 0.0F, 0.0F);
        box(P[5], 66, 30, -0.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        box(P[5], 66, 27, -1.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        box(P[5], 66, 24, -2.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        P[6] = part(P[1], "pierna_izquierda", 4.0F, -12.0F, 0.5F, 0.0F, 0.0F, 0.0F);
        box(P[6], 16, 49, -2.0F, -1.0F, -2.0F, 4, 13, 4, -0.1F);
        P[7] = part(P[6], "pie_izquierdo", 4.0F, 12.0F, -0.5F, 0.0F, 0.0F, 0.0F);
        box(P[7], 66, 19, -5.5F, -2.0F, -3.0F, 3, 2, 3, 0.0F);
        P[8] = part(P[7], "garras_pie_izquierdo", -1.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F);
        P[9] = part(P[8], "cube_r3", -2.0F, 0.0F, -3.0F, 0.6109F, 0.0F, 0.0F);
        box(P[9], 72, 27, -0.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        box(P[9], 72, 24, -1.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        box(P[9], 26, 71, -2.5F, -1.2F, -1.2F, 1, 1, 2, -0.3F);
        P[10] = part(P[8], "cube_r4", -2.0F, 0.0F, -2.0F, -0.1309F, 0.0F, 0.0F);
        box(P[10], 20, 71, -0.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        box(P[10], 68, 45, -1.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        box(P[10], 68, 42, -2.5F, -1.0F, -1.5F, 1, 1, 2, -0.1F);
        P[11] = part(P[1], "cuerpo", 2.0F, -12.0F, 0.5F, 0.0F, 0.0F, 0.0F);
        P[12] = part(P[11], "torso", -2.0F, 12.0F, -0.5F, 0.0F, 0.0F, 0.0F);
        box(P[12], 34, 48, -2.0F, -24.0F, -1.5F, 8, 12, 4, 0.0F);
        P[13] = part(P[11], "brazo_izquierdo", 5.9983F, -11.5109F, 0.0F, 0.0F, 0.0F, -0.0436F);
        P[14] = part(P[13], "brazo_izquierdo_r1", -2.5F, 11.5F, -0.5F, 0.0F, 0.0F, -0.0436F);
        box(P[14], 58, 48, 0.5F, -12.0F, -1.5F, 4, 12, 4, -0.2F);
        P[15] = part(P[13], "garra_i1", -0.5F, 12.5F, -0.5F, 0.0F, 0.0F, 0.0F);
        P[16] = part(P[15], "cube_r5", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[16], 14, 74, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[17] = part(P[15], "cube_r6", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[17], 10, 74, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[18] = part(P[13], "garra_i2", 0.5F, 12.5F, -1.5F, -0.0873F, -1.309F, 0.0F);
        P[19] = part(P[18], "cube_r7", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[19], 22, 74, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[20] = part(P[18], "cube_r8", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[20], 18, 74, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[21] = part(P[13], "garra_i3", 0.5F, 12.5F, -0.5F, -1.6129F, -1.5482F, 1.5286F);
        P[22] = part(P[21], "cube_r9", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[22], 74, 33, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[23] = part(P[21], "cube_r10", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[23], 26, 74, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[24] = part(P[13], "garra_i4", 0.5F, 12.5F, 0.5F, -3.0966F, -1.0458F, 3.0183F);
        P[25] = part(P[24], "cube_r11", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[25], 74, 39, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[26] = part(P[24], "cube_r12", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[26], 74, 36, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[27] = part(P[11], "brazo_derecho", -5.4556F, -10.9107F, 0.0F, 0.0F, 0.0F, 0.0873F);
        box(P[27], 32, 64, -2.0F, -1.0F, -2.0F, 4, 12, 4, -0.2F);
        P[28] = part(P[27], "garra_d1", -0.5F, 12.0F, -0.5F, 0.0F, 0.0F, 0.0F);
        P[29] = part(P[28], "cube_r13", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[29], 48, 73, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[30] = part(P[28], "cube_r14", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[30], 72, 30, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[31] = part(P[27], "garra_d2", -0.5F, 12.0F, -0.5F, 0.0F, 1.2217F, 0.0F);
        P[32] = part(P[31], "cube_r15", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[32], 56, 73, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[33] = part(P[31], "cube_r16", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[33], 52, 73, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[34] = part(P[27], "garra_d3", -0.5F, 12.0F, 0.5F, 0.0F, 1.5708F, 0.0F);
        P[35] = part(P[34], "cube_r17", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[35], 64, 73, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[36] = part(P[34], "cube_r18", 0.0F, 0.0F, -2.0F, -0.3491F, 0.0F, 0.0F);
        box(P[36], 60, 73, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[37] = part(P[27], "garra_d4", -0.5F, 12.0F, 1.5F, 0.0F, 1.9635F, 0.0F);
        P[38] = part(P[37], "cube_r19", 0.0F, 2.0F, -1.0F, 0.3491F, 0.0F, 0.0F);
        box(P[38], 72, 73, 0.0F, -2.5F, -0.4F, 1, 2, 1, -0.3F);
        P[39] = part(P[37], "cube_r20", 0.0F, 0.0F, -2.0F, -0.5672F, 0.0F, 0.0F);
        box(P[39], 68, 73, 0.0F, -2.0F, 0.0F, 1, 2, 1, -0.1F);
        P[40] = part(P[11], "cabeza", 0.0F, -12.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        box(P[40], 0, 0, -8.0F, -11.5F, -8.5F, 16, 17, 17, -5.5F);
        box(P[40], 34, 34, -4.0F, -4.2F, -7.5F, 8, 5, 9, -2.9F);
        box(P[40], 0, 34, -4.0F, -5.5F, -7.5F, 8, 6, 9, -2.5F);
        box(P[40], 48, 64, -2.3F, -4.3F, -6.7F, 4, 5, 4, -1.8F);
        box(P[40], 64, 64, -1.8F, -4.3F, -6.7F, 4, 5, 4, -1.8F);
    }
    private void build1() {
        P[41] = part(P[40], "orejas", -0.5F, -5.0F, 2.0F, 0.0F, 0.0F, 0.0F);
        P[42] = part(P[41], "cube_r21", 2.5F, -3.0F, -8.5F, -1.0531F, -0.056F, 0.211F);
        box(P[42], 10, 66, -0.6F, -8.2F, -1.1F, 3, 6, 2, -0.6F);
        P[43] = part(P[41], "cube_r22", 1.5F, 1.0F, 0.5F, 0.2559F, -0.056F, 0.211F);
        box(P[43], 66, 0, -1.0F, -9.0F, -1.0F, 3, 9, 2, -0.4F);
        P[44] = part(P[41], "cube_r23", -5.5F, -2.0F, -9.5F, -1.1141F, 0.2926F, -0.1691F);
        box(P[44], 66, 11, -0.7F, -9.0F, -1.3F, 3, 6, 2, -0.6F);
        P[45] = part(P[41], "cube_r24", -1.5F, 1.0F, 0.5F, 0.3924F, 0.0167F, -0.3021F);
        box(P[45], 0, 66, -1.0F, -9.0F, -1.0F, 3, 9, 2, -0.4F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        resetPose();
        float t = ageInTicks;
        float ch = ((EntityConejo) entityIn).getAnimPersecucion(ageInTicks - (float) entityIn.ticksExisted);
        float amt = MathHelper.clamp(limbSwingAmount, 0.0F, 1.0F);
        float ph = limbSwing * 0.6662F;
        float zancada = 1.0F + 0.25F * ch;
        piernaDerecha.rotateAngleX += MathHelper.cos(ph) * zancada * amt;
        piernaIzquierda.rotateAngleX += MathHelper.cos(ph + PI) * zancada * amt;
        conejo.rotationPointY -= MathHelper.abs(MathHelper.sin(ph)) * (1.0F + 1.2F * ch) * amt;
        float resp = MathHelper.sin(t * 0.07F);
        cuerpo.rotateAngleX += resp * 0.03F + ch * 0.45F + amt * 0.06F;
        cuerpo.rotateAngleY += -MathHelper.cos(ph) * 0.18F * amt;
        cuerpo.rotateAngleZ += MathHelper.cos(ph) * 0.05F * amt * (1.0F + ch);
        float sway = MathHelper.cos(t * 0.09F) * 0.04F + 0.03F;
        float aD = MathHelper.cos(ph + PI) * 0.9F * amt * (1.0F - ch);
        float aI = MathHelper.cos(ph) * 0.9F * amt * (1.0F - ch);
        float cD = (-1.75F + MathHelper.sin(t * 0.9F) * 0.25F) * ch;
        float cI = (-1.75F + MathHelper.sin(t * 0.9F + PI) * 0.25F) * ch;
        brazoDerecho.rotateAngleX += aD + cD;
        brazoDerecho.rotateAngleY += -0.15F * ch;
        brazoDerecho.rotateAngleZ += sway + 0.12F * ch;
        brazoIzquierdo.rotateAngleX += aI + cI;
        brazoIzquierdo.rotateAngleY += 0.15F * ch;
        brazoIzquierdo.rotateAngleZ += -sway - 0.12F * ch;
        float sw = this.swingProgress;
        if (sw > 0.0F) {
            float s1 = MathHelper.sin(sw * PI);
            float s2 = MathHelper.sin(MathHelper.clamp(sw * 1.35F - 0.35F, 0.0F, 1.0F) * PI);
            brazoDerecho.rotateAngleX += -s1 * 1.3F;
            brazoDerecho.rotateAngleZ += s1 * 0.35F;
            brazoIzquierdo.rotateAngleX += -s2 * 1.3F;
            brazoIzquierdo.rotateAngleZ += -s2 * 0.35F;
            cuerpo.rotateAngleX += s1 * 0.2F;
            cuerpo.rotateAngleY += -s1 * 0.25F + s2 * 0.25F;
        }
        float garra = MathHelper.sin(t * 0.6F) * 0.25F * ch;
        for (ModelRenderer g : garras) {
            g.rotateAngleX += garra;
        }
        float twitch = 0.0F;
        int paso = (int) (t / 10.0F);
        int h = ((paso * 73856093) ^ (entityIn.getEntityId() * 19349663)) & 65535;
        if (h % 4 == 0) {
            float k = (t % 10.0F) / 10.0F;
            twitch = ((h & 1) == 0 ? 0.45F : -0.45F) * Math.min(1.0F, k * 6.0F) * (1.0F - k);
        }
        cabeza.rotateAngleY += netHeadYaw * 0.0174533F;
        cabeza.rotateAngleX += headPitch * 0.0174533F - ch * 0.4F - amt * 0.05F;
        cabeza.rotateAngleZ += MathHelper.sin(t * 0.05F) * 0.07F + twitch + MathHelper.sin(t * 1.7F) * 0.08F * ch;
        orejas.rotateAngleX += MathHelper.sin(t * 0.11F) * 0.05F - 0.35F * ch + MathHelper.sin(ph * 2.0F) * 0.08F * amt;
    }
}
