package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

/**
 * Monstruo Sonrisas: no ataca ni hace ruido al caminar. Ciega a TODOS los jugadores del mundo (cada 5 ticks),
 * y a menos de 20 bloques aplica lentitud (por distancia) y veneno cada 25 ticks.
 */
public class EntitySonrisas extends EntityMiniBase {
    private int contadorSonido;

    public EntitySonrisas(World world) {
        super(world, 0.9F, 2.0F);
        this.contadorSonido = 300 + this.rand.nextInt(101);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(45.0D, 0.23D, 0.0D, 40.0D, 0.3D);
    }

    @Override
    protected void initEntityAI() {
        addStandardGoals(1.1D, 0.7D);
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        return false;
    }

    @Override
    protected void playStepSound(BlockPos pos, Block block) {
        // silencioso, como el original
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote || !this.isEntityAlive()) {
            return;
        }
        if (this.ticksExisted % 5 == 0) {
            aplicarCeguera();
            aplicarEfectosCercanos(this.ticksExisted % 25 == 0);
        }
        if (--this.contadorSonido <= 0) {
            this.playSound(this.rand.nextInt(2) == 0 ? ModSounds.SUSURRO_1 : ModSounds.SUSURRO_2, 1.5F, 1.0F);
            this.contadorSonido = 300 + this.rand.nextInt(101);
        }
    }

    private void aplicarCeguera() {
        for (EntityPlayer p : this.world.playerEntities) {
            if (!p.isSpectator() && p.isEntityAlive()) {
                p.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 60, 0, true, true));
            }
        }
    }

    private void aplicarEfectosCercanos(boolean veneno) {
        AxisAlignedBB box = this.getEntityBoundingBox().grow(20.0D);
        List<EntityPlayer> players = this.world.getEntitiesWithinAABB(EntityPlayer.class, box,
                p -> p != null && !p.isSpectator() && p.isEntityAlive());
        for (EntityPlayer p : players) {
            double dist = Math.sqrt(this.getDistanceSq(p));
            if (dist > 20.0D) {
                continue;
            }
            p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, EntityGuardian.nivelLentitud(dist), true, true));
            if (veneno) {
                p.addPotionEffect(new PotionEffect(MobEffects.POISON, 40, 0, true, true));
            }
        }
    }
}
