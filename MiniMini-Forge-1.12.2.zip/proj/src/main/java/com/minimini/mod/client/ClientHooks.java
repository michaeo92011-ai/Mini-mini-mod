package com.minimini.mod.client;

import com.minimini.mod.MiniMiniMod;
import com.minimini.mod.ModPotions;
import com.minimini.mod.entity.EntityMiniMini;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.List;

/** HUD de Mini Mini (marco + vida) y efecto visual de Oscuridad. */
public class ClientHooks {
    private static final ResourceLocation BARRA =
            new ResourceLocation(MiniMiniMod.MODID, "textures/gui/minimini_barra_vida.png");

    /** Oscuridad: oscurece la pantalla por debajo del HUD. */
    @SubscribeEvent
    public void onOverlayPre(RenderGameOverlayEvent.Pre event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        if (player == null) {
            return;
        }
        PotionEffect eff = player.getActivePotionEffect(ModPotions.OSCURIDAD);
        if (eff == null) {
            return;
        }
        float fade = Math.min(1.0F, eff.getDuration() / 40.0F);
        float pulse = 0.85F + 0.15F * (float) Math.sin(player.ticksExisted * 0.15D);
        int alpha = (int) (200.0F * fade * pulse);
        if (alpha > 0) {
            Gui.drawRect(0, 0, event.getResolution().getScaledWidth(), event.getResolution().getScaledHeight(),
                    (alpha << 24));
        }
    }

    /** Barra de vida: marco 240x87 centrado arriba + número de vida del Mini Mini más cercano (48 bloques). */
    @SubscribeEvent
    public void onOverlayPost(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null || mc.gameSettings.hideGUI) {
            return;
        }
        List<EntityMiniMini> lista = mc.world.getEntitiesWithinAABB(EntityMiniMini.class,
                mc.player.getEntityBoundingBox().grow(48.0D), e -> e != null && e.isEntityAlive());
        EntityMiniMini cercano = null;
        double mejor = Double.MAX_VALUE;
        for (EntityMiniMini e : lista) {
            double d = e.getDistanceSq(mc.player);
            if (d < mejor) {
                mejor = d;
                cercano = e;
            }
        }
        if (cercano == null) {
            return;
        }
        FontRenderer font = mc.fontRenderer;
        int w = event.getResolution().getScaledWidth();
        int x = w / 2 - 120;
        int y = 14;
        String nombre = I18n.format("entity.minimini.minimini.name");
        font.drawStringWithShadow(nombre, w / 2 - font.getStringWidth(nombre) / 2, y, 0xFF4E9BFF);
        int yBarra = y + 9 + 4;
        GlStateManager.enableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        mc.getTextureManager().bindTexture(BARRA);
        Gui.drawScaledCustomSizeModalRect(x, yBarra, 0.0F, 0.0F, 480, 174, 240, 87, 480.0F, 174.0F);
        String vida = String.valueOf(Math.max(0, Math.round(cercano.getHealth())));
        font.drawStringWithShadow(vida, w / 2 - font.getStringWidth(vida) / 2, yBarra + 87 + 2, 0xFFFFAA00);
    }
}
