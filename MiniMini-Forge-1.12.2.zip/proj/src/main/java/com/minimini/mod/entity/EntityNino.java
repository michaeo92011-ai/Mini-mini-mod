package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.world.World;

/** Niño de los Backrooms: 30 HP, 5 de daño, habla cada ~20 s y corre a cuatro patas al perseguir. */
public class EntityNino extends EntityMiniBase {
    public float animCuadrupedo;
    public float animCuadrupedoPrev;
    private int contadorVoz;

    public EntityNino(World world) {
        super(world, 0.6F, 1.45F);
        this.contadorVoz = 100 + this.rand.nextInt(300);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        setAttributes(30.0D, 0.25D, 5.0D, 40.0D, 0.2D);
    }

    @Override
    protected void initEntityAI() {
        addStandardGoals(1.8D, 0.8D);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote) {
            this.animCuadrupedoPrev = this.animCuadrupedo;
            float objetivo = this.isChasing() ? 1.0F : 0.0F;
            this.animCuadrupedo += (objetivo - this.animCuadrupedo) * 0.15F;
        } else if (this.isEntityAlive()) {
            if (--this.contadorVoz <= 0) {
                this.playSound(ModSounds.NINO_VOZ, 1.3F, 1.0F);
                this.contadorVoz = 400;
            }
        }
    }

    public float getAnimCuadrupedo(float partialTicks) {
        return this.animCuadrupedoPrev + partialTicks * (this.animCuadrupedo - this.animCuadrupedoPrev);
    }
}
