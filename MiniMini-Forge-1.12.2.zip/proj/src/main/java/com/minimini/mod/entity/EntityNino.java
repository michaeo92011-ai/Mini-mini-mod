package com.minimini.mod.entity;

import com.minimini.mod.ModSounds;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

/** Niño de los Backrooms: pequeño, habla solo; únicamente ataca si lo hieren. */
public class EntityNino extends EntityMiniBase {

    public EntityNino(World world) {
        super(world, 0.45F, 1.3F);
        this.experienceValue = 5;
    }

    @Override
    protected boolean aggressiveByDefault() {
        return false;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.28D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Override
    public int getTalkInterval() {
        return 160;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.NINO_VOZ;
    }
}
