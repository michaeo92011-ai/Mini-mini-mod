# Mini Mini.exe — port para Forge 1.12.2 (versión "inspirada")

Reescritura desde cero de los 6 mobs del mod Fabric 1.21.1 de goldbullshit.
Reutiliza los 10 sonidos originales. Las texturas son NUEVAS (las originales usan
un mapa UV propio de sus modelos 1.21 y se verían rotas aquí).

## Mobs
| Mob | Comportamiento |
|---|---|
| Mini Mini.exe | Jefe (80 HP, barra de jefe). Grito ultrasónico cada ~15 s: daño + náusea + lentitud + ceguera en 12 bloques |
| Conejo de los Backrooms | Rápido, hostil, sonidos de conejo graves |
| Niño de los Backrooms | Habla solo; solo ataca si lo hieren |
| Guardián del Bosque | 80 HP, aparece de día en bosques; ataca si lo hieren o ves con un hacha |
| Monstruo Sonrisas | Rápido, susurra, su golpe ralentiza |
| Ojos Linterna | Criatura de oscuridad, su golpe ciega |

Cada uno tiene huevo generador (pestaña Varios): se ve como un huevo de colores normal.

## Compilar (necesitas JDK 8)
1. Descarga el MDK de Forge 1.12.2 (14.23.5.2860) desde files.minecraftforge.net.
2. Descomprímelo y reemplaza su carpeta `src/` por la de este proyecto (y su build.gradle por el mío si quieres).
3. En esa carpeta: `gradlew setupDecompWorkspace` y luego `gradlew build`.
4. El .jar queda en `build/libs/`. Cópialo a `.minecraft/mods` con Forge 1.12.2 instalado.
   Para probar: `gradlew runClient`, y /summon minimini:conejo (o los otros nombres).

IDs de entidad: minimini:minimini, minimini:conejo, minimini:nino,
minimini:guardian_bosque, minimini:monstruo_sonrisas, minimini:ojos_linterna

## Aviso
El código NO se pudo compilar en el entorno donde lo escribí (sin Forge ni internet).
Si Gradle marca un error, mándamelo y lo corrijo.
Licencia del mod original: All Rights Reserved. Uso personal; para publicarlo pide permiso al autor.
