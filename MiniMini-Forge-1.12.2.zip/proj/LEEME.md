# Mini Mini.exe — port FIEL para Forge 1.12.2 (opción A)

Reconstruido leyendo el bytecode del mod original (Fabric 1.21.1):
modelos exactos (399 piezas de Mini Mini, UV y pivotes), texturas y sonidos originales,
atributos, IA y habilidades de cada mob, barra de vida del HUD y huevo de Mini Mini.

Como el original, los mobs NO aparecen solos: usa los huevos generadores (pestaña Varios)
o /summon minimini:<nombre>.

| Mob | Qué hace (copiado del original) |
|---|---|
| Mini Mini.exe | 500 HP, 30 de daño, inmune al empuje. Grito ultrasónico (aviso 20 ticks, cada 15-20 s): náusea, lentitud y oscuridad a jugadores que lo vean a <20 bloques. Al morir da 5 niveles al jugador que lo mató. HUD con marco y vida |
| Conejo de los Backrooms | 60 HP, 8 de daño, rápido; chilla al empezar a perseguir; anda erguido y corre a cuatro patas |
| Niño de los Backrooms | 30 HP, 5 de daño; habla cada ~20 s; corre a cuatro patas al perseguir |
| Guardián del Bosque | 45 HP, NO golpea: aura de 20 bloques con lentitud (más fuerte cerca) y Wither cada 2 s |
| Monstruo Sonrisas | 45 HP, NO golpea; CIEGA a todos los jugadores del mundo; lentitud y veneno a <20 bloques |
| Ojos Linterna | 30 HP, 12 de daño, muy lento (0.1), 1.5 s entre golpes |

Diferencia inevitable: el efecto "Oscuridad" de 1.19+ no existe en 1.12.2, así que añadí uno propio
que oscurece la pantalla de forma parecida.
